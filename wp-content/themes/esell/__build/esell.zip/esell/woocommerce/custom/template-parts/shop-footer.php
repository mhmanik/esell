<?php
/**
 * @author  axiltheme
 * @since   1.0
 * @version 1.0
 */


?>
				</div>
			</div>
			<?php Helper::wooc_axil_right_get_sidebar();?>
		</div><!-- .row -->
	</div><!-- container -->
</div><!-- #primary -->