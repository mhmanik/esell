<?php
/*
Plugin Name: Umart Elements
Plugin URI: https://www.wooctheme.club
Description: Umart Elements Plugin for Umart Theme
Version: 1.0
Author: WoocTheme
Author URI: https://www.wooctheme.club
*/

if (!defined('ABSPATH')) exit;

if (!defined('UMART_ELEMENTS')) {
    $plugin_data = get_file_data(__FILE__, array('version' => 'Version'));
    define('UMART_ELEMENTS', $plugin_data['version']);
    define('UMART_ELEMENTS_SCRIPT_VER', (WP_DEBUG) ? time() : UMART_ELEMENTS);
    define('UMART_ELEMENTS_THEME_PREFIX', 'umart');
    define('UMART_ELEMENTS_BASE_DIR', plugin_dir_path(__FILE__));
}

class umart_elements
{

    public $plugin = 'umart-elements';
    public $action = 'umart_theme_init';
    protected static $instance;

    public function __construct()
    {
        add_action('plugins_loaded', array($this, 'load_textdomain'), 20);
        add_action($this->action, array($this, 'after_theme_loaded'));
        add_action('wooctheme_social_share', array($this, 'wooc_social_share'));
    }

    public static function instance()
    {
        if (null == self::$instance) {
            self::$instance = new self;
        }
        return self::$instance;
    }

    public function after_theme_loaded()
    {
        require_once UMART_ELEMENTS_BASE_DIR . 'plugin-hooks.php'; // Plugin Hooks
        require_once UMART_ELEMENTS_BASE_DIR . 'lib/wp-svg/init.php'; // SVG support
        require_once UMART_ELEMENTS_BASE_DIR . 'lib/sidebar-generator/init.php'; // Sidebar generator
        require_once UMART_ELEMENTS_BASE_DIR . 'lib/navmenu-icon/init.php'; // Navmenu icon support

        if (did_action('elementor/loaded')) {
            require_once UMART_ELEMENTS_BASE_DIR . 'elementor/init.php'; // Elementor
            require_once UMART_ELEMENTS_BASE_DIR . 'elementor/helper.php'; // Elementor
        }
    }

    public function wooc_social_share($sharer)
    {
        include UMART_ELEMENTS_BASE_DIR . 'inc/social-share.php';
    }

    public function load_textdomain()
    {
        load_plugin_textdomain($this->plugin, false, dirname(plugin_basename(__FILE__)) . '/languages');
    }
}

umart_elements::instance();