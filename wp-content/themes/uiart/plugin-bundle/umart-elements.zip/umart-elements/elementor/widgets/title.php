<?php
/**
 * @author  WoocTheme
 * @since   1.0
 * @version 1.0
 */

namespace wooctheme\umart_elements;

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widget_Base;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
class Title extends Widget_Base {  

 public function get_name() {
        return 'wooc-title';
    }    
    public function get_title() {
        return __( 'Section Title', 'umart-elements' );
    }
    public function get_icon() {
        return 'eicon-post-title';
    }
    public function get_categories() {
        return [ UMART_ELEMENTS_THEME_PREFIX . '-widgets' ];
    }
  
  protected function _register_controls() {

     $this->start_controls_section(
            'title_section',
            [
                'label' => __( 'Section Title Layout', 'umart-elements' ),
            ]
        );
            
        $this->add_control(
            'style',
            [
                'label' => __( 'Style', 'umart-elements' ),
                'type' => Controls_Manager::SELECT,
                'default' => '1',
                'options' => [
                    '1'   => __( 'Style One', 'umart-elements' ),
                    '2'   => __( 'Style Two', 'umart-elements' ),                  
                    
                ],
            ] 
        );
      

        $this->add_responsive_control(
        'section_title_margin',
        [
            'label' => __( 'Section Margin', 'umart-elements' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
             'condition' => array( 'before_title_style_on' => array( 'yes' ) ),
            'selectors' => [
                '{{WRAPPER}} .wooc-title-block-1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                
            ],
        ]
        );
        
        $this->add_responsive_control(
            'title_align',
            [
                'label'   => __( 'Alignment (flex)', 'umart-elements' ),
                'type'    => Controls_Manager::CHOOSE,
                 'condition' => array( 'style' => array( '1' ) ),
                'options' => [
                    'flex-start'    => [
                        'title' => __( 'Left', 'umart-elements' ),
                        'icon'  => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'umart-elements' ),
                        'icon'  => 'fa fa-align-center',
                    ],
                    'flex-end' => [
                        'title' => __( 'Right', 'umart-elements' ),
                        'icon'  => 'fa fa-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wooc-title-block-1'   => 'justify-content: {{VALUE}}',
                    
                ],
                'default' => 'center',
            ]
        ); 

        $this->add_responsive_control(
            'title_text_align',
            [
                'label'   => __( 'Alignment (text-align)', 'umart-elements' ),
                'type'    => Controls_Manager::CHOOSE,
                 'condition' => array( 'style' => array( '1' ) ),
                'options' => [
                    'left'    => [
                        'title' => __( 'Left', 'umart-elements' ),
                        'icon'  => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'umart-elements' ),
                        'icon'  => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'umart-elements' ),
                        'icon'  => 'fa fa-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wooc-title-block-1'   => 'text-align: {{VALUE}}',
                    
                ],
                'default' => 'center',
            ]
        );
      

        $this->add_responsive_control(
            'title_align2',
            [
                'label'   => __( 'Alignment', 'umart-elements' ),
                'type'    => Controls_Manager::CHOOSE,
                 'condition' => array( 'style' => array( '2' ) ),
                    'options' => [
                        'space-between'    => [
                            'title' => __( 'Left', 'umart-elements' ),
                            'icon'  => 'fa fa-align-left',
                        ],
                        'center' => [
                            'title' => __( 'Center', 'umart-elements' ),
                            'icon'  => 'fa fa-align-center',
                        ],
                        'flex-end' => [
                            'title' => __( 'Right', 'umart-elements' ),
                            'icon'  => 'fa fa-align-right',
                        ],
                    ],
                'selectors' => [                    
                    '{{WRAPPER}} .wooc-slider-title-block-1'   => 'text-align: {{VALUE}};',
                    '{{WRAPPER}} .wooc-slider-title-block-1'   => 'justify-content: {{VALUE}};',
                ],
                'default' => 'space-between',
            ]
        );

        $this->end_controls_section();

     $this->start_controls_section(
            'title_before_section',
            [
                'label' => __( 'Title Right', 'umart-elements' ),
                'condition' => [
                    'style' => '2',
                ],  

            ]

        );
         $this->add_control(
            'islink',
            [
                
                'type' => Controls_Manager::SWITCHER,
                'label'       => __( 'Detail Link', 'umart-elements' ),
                'label_on'    => __( 'On', 'umart-elements' ),
                'label_off'   => __( 'Off', 'umart-elements' ),
                'default'     => 'no',               
                
            ] 
        );                    

        $this->add_control(
            'btntext',
            [
                'label'   => __( 'Button Text', 'umart-elements' ),
                'type'    => Controls_Manager::TEXT,
                'default' => 'LOREM IPSUM',
            ]
        );
        $this->add_control(
            'url',
            [
                'label'   => __( 'Button Link', 'umart-elements' ),
                'type'    => Controls_Manager::URL,
                'placeholder' => 'https://your-link.com',
                
            ]
        );  

        $this->end_controls_section();



        $this->start_controls_section(
            'title_text_section',
            [
                'label' => __( 'Title', 'umart-elements' ),
            ]
        );
        $this->add_responsive_control(
            'sec_title_tag',
            [
                'label' => __( 'Title HTML Tag', 'umart-elements' ),
                'type' => Controls_Manager::CHOOSE,
                 'options' => [
                      'h1'  => [
                        'title' => esc_html__( 'H1', 'umart-elements' ),
                        'icon' => 'eicon-editor-h1'
                    ],
                    'h2'  => [
                        'title' => esc_html__( 'H2', 'umart-elements' ),
                        'icon' => 'eicon-editor-h2'
                    ],
                    'h3'  => [
                        'title' => esc_html__( 'H3', 'umart-elements' ),
                        'icon' => 'eicon-editor-h3'
                    ],
                    'h4'  => [
                        'title' => esc_html__( 'H4', 'umart-elements' ),
                        'icon' => 'eicon-editor-h4'
                    ],
                    'h5'  => [
                        'title' => esc_html__( 'H5', 'umart-elements' ),
                        'icon' => 'eicon-editor-h5'
                    ],
                    'h6'  => [
                        'title' => esc_html__( 'H6', 'umart-elements' ),
                        'icon' => 'eicon-editor-h6'
                    ],
                    'div'  => [
                        'title' => esc_html__( 'div', 'umart-elements' ),
                        'icon' => 'eicon-font'
                    ]
                ],
                'default' => 'h2',               

            ]
        );
        $this->add_control(
            'title',
            [
                'label' => __( 'Title', 'umart-elements' ),
                'type' => Controls_Manager::TEXTAREA,
                'placeholder' => __( 'Type your title here...', 'umart-elements' ),
                'default' => 'Section title here',
            ]
        ); 
       $this->end_controls_section();


        $this->start_controls_section(
            'sub_title_section',
            [
                'label' => __( 'Sub Title', 'umart-elements' ),
            ]
        );
        
       $this->add_control(
            'sub_title',
            [
                'label' => __( 'Description', 'umart-elements' ),
                'type' => Controls_Manager::TEXTAREA,
                'placeholder' => __( 'Type your Description here.', 'umart-elements' ),    
                 'default' => 'Section sub title here',            
            ]
        );
        $this->end_controls_section();
       
        $this->start_controls_section(
            'before_title_style_section',
            [
                'label' => __( 'Title Before', 'umart-elements' ),
                'tab' => Controls_Manager::TAB_STYLE,                
            ]
        );

         $this->add_control(
            'before_title_style_on',
            [
                'label' => __( 'Customize', 'umart-elements' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on'    => __( 'On', 'umart-elements' ),
                'label_off'   => __( 'Off', 'umart-elements' ),
                'default'     => 'no',
               
            ]
        );  
          $this->add_control(
            'before_title_color',
            [
                'label' => __( 'Color', 'umart-elements' ),
                'type' => Controls_Manager::COLOR,  
                'default' => '',
                'condition' => array( 'before_title_style_on' => array( 'yes' ) ),
                'selectors' => array(
                    '{{WRAPPER}} .woocue-sub-title:after' => 'background-color: {{VALUE}}',
                ),
            ]
        );

    $this->end_controls_section();     
        $this->start_controls_section(
            'title_style_section',
            [
                'label' => __( 'Title', 'umart-elements' ),
                'tab' => Controls_Manager::TAB_STYLE,                
            ]
        );

         $this->add_control(
            'title_style_on',
            [
                'label' => __( 'Customize', 'umart-elements' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on'    => __( 'On', 'umart-elements' ),
                'label_off'   => __( 'Off', 'umart-elements' ),
                'default'     => 'no',
               
            ]
        );   

 
          $this->add_control(
            'title_color',
            [
                'label' => __( 'Color', 'umart-elements' ),
                'type' => Controls_Manager::COLOR,  
                'default' => '',
                'condition' => array( 'title_style_on' => array( 'yes' ) ),
                'selectors' => array(
                    '{{WRAPPER}} .woocue-sec-title' => 'color: {{VALUE}}',
                ),
            ]
        );

         $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_font_size',
                'label' => __( 'Typography', 'umart-elements' ),                
                 'condition' => array( 'title_style_on' => array( 'yes' ) ),
                'selector' => '{{WRAPPER}} .woocue-sec-title',
            ]
        );
       
        $this->add_responsive_control(
            'title_margin',
            [
                'label' => __( 'Margin', 'umart-elements' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                 'condition' => array( 'title_style_on' => array( 'yes' ) ),
                'selectors' => [
                    '{{WRAPPER}} .woocue-sec-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
            ]
        );
       
    $this->end_controls_section();


        $this->start_controls_section(
            'abc_sub_title_style_section',
            [
                'label' => __( 'Sub Title', 'umart-elements' ),
                'tab' => Controls_Manager::TAB_STYLE,                
            ]
        );

         $this->add_control(
            'sub_title_style_on',
            [
                'label' => __( 'Customize', 'umart-elements' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on'    => __( 'On', 'umart-elements' ),
                'label_off'   => __( 'Off', 'umart-elements' ),
                'default'     => 'no',
               
            ]
        );   

 
          $this->add_control(
            'sub_title_color',
            [
                'label' => __( 'Color', 'umart-elements' ),
                'type' => Controls_Manager::COLOR,  
                'default' => '',
                'condition' => array( 'sub_title_style_on' => array( 'yes' ) ),
                'selectors' => array(
                    '{{WRAPPER}} .woocue-sub-title' => 'color: {{VALUE}}',
                ),
            ]
        );

         $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'sub_title_font_size',
                'label' => __( 'Typography', 'umart-elements' ),                
                 'condition' => array( 'sub_title_style_on' => array( 'yes' ) ),
                'selector' => '{{WRAPPER}} .woocue-sub-title',
            ]
        );
       
        $this->add_responsive_control(
            'sub_title_margin',
            [
                'label' => __( 'Margin', 'umart-elements' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                 'condition' => array( 'sub_title_style_on' => array( 'yes' ) ),
                'selectors' => [
                    '{{WRAPPER}} .woocue-sub-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
            ]
        );
       
    $this->end_controls_section();

  }


    protected function render() {
        $settings = $this->get_settings();
        $template   = 'title-' . str_replace("style", "", $settings['style']);                 
        return wooc_Elements_Helper::wooc_element_template( $template, $settings );
    }
}
