<?php
/**
 * @author  WoocTheme
 * @since   1.0
 * @version 1.0
 */

namespace wooctheme\umart_elements;
use Elementor\Group_Control_Image_Size;
use Elementor\Icons_Manager;

$attr = $btn = $price ='';
$class = 'woocue-style-1';
$class .= ' woocue-'.$settings['content_pos'];

$wrapper_start = '<div class="woocue-item">';
$wrapper_end   = '</div>';

if ( !empty( $settings['url']['url'] ) ) {
	$attr  = 'href="' . $settings['url']['url'] . '"';
	$attr .= !empty( $settings['url']['is_external'] ) ? ' target="_blank"' : '';
	$attr .= !empty( $settings['url']['nofollow'] ) ? ' rel="nofollow"' : '';
}

if ( $settings['price'] ) {
	$price = '<div class="price-pos-'.$settings['price_pos_y_type'] .' woocue-price '.$settings['pricebtnstyle'] .' price-pos-'.$settings['price_pos_x_type'] .'">'.$settings['price'].'</div>';
}
if ( $settings['url']['url'] ) {
	$wrapper_start = '<a class="woocue-item" ' . $attr . '>';
	$wrapper_end   = '</a>';
	}
$img =   Group_Control_Image_Size::get_attachment_image_html( $settings, 'pimage_size', 'image' );
?>

<div class="woocue-info-box <?php echo esc_attr( $class );?>">
	<?php echo wp_kses_post( $wrapper_start);?>
	<?php echo wp_kses_post( $price);?>
	<div class="woocue-img woocue-pos-<?php echo esc_attr( $settings['pos_y_type'] );?> woocue-pos-<?php echo esc_attr( $settings['pos_x_type'] );?>">
		<?php echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'pimage_size', 'image' );?>	
	</div>
	<div class="woocue-content-area">
		<div class="woocue-content">
			<?php if ( $settings['subtitle'] ): ?>
				<span class="woocue-subtitle"><?php echo wp_kses_post( $settings['subtitle'] );?></span>
			<?php endif; ?>			
			<?php if ( $settings['title'] ): ?>
				<h3 class="woocue-title"><?php echo wp_kses_post( $settings['title'] );?></h3>
			<?php endif; ?>
		</div>		
	</div>
	<?php echo wp_kses_post( $wrapper_end );?>
</div>