<?php
/**
 * @author  WoocTheme
 * @since   1.0
 * @version 1.0
 */
namespace wooctheme\umart_elements;
use Elementor\Group_Control_Image_Size;
use Elementor\Icons_Manager;

?>

<div class="wooc-icon-wrp media">		
	<?php if ( $settings['icontype'] == 'image' ): ?>
		<div class="img-box">
			<?php echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'image_size', 'image' );?> 
		 </div>
		<?php else: ?>
		<div class="feature-icon">
			<?php Icons_Manager::render_icon( $settings['icon'] ); ?>
		</div>
	<?php endif; ?>	

	<div class="wooc-content-area media-body">
		<div class="wooc-content">
			<?php if ( $settings['subtitle'] ): ?>
				<span class="wooc-subtitle"><?php echo wp_kses_post( $settings['subtitle'] );?></span>
			<?php endif; ?>
			<?php if ( $settings['title'] ): ?>
				<h2 class="wooc-title"><?php echo wp_kses_post( $settings['title'] );?></h2>
			<?php endif; ?>		
			
		</div>
	</div>			
</div>	