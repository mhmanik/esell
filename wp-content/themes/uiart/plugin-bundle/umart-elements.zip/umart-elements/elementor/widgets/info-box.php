<?php
/**
 * @author  WoocTheme
 * @since   1.0
 * @version 1.0
 */

namespace wooctheme\umart_elements;

use Elementor\Widget_Base;
use Elementor\Group_Control_Css_Filter;
use Elementor\Repeater;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\DATE_TIME;
use Elementor\SLIDER;
use Elementor\CHOOSE;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Info_Box extends Widget_Base {

 public function get_name() {
        return 'wooc-info-box';
    }    
    public function get_title() {
        return __( 'Info Box', 'umart-elements' );
    }
    public function get_icon() {
        return ' eicon-image-box';
    }
    public function get_categories() {
        return [ UMART_ELEMENTS_THEME_PREFIX . '-widgets' ];
    }

    protected function _register_controls() {
              
        $this->start_controls_section(
            'services_layout',
            [
                'label' => __( 'General', 'umart-elements' ),
            ]
        );
             

		$this->add_responsive_control(
			'height',
			[
				'label' => __( 'Box Height', 'umart-elements' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 200,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 180,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 160,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .woocue-item' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
			

		$this->add_control(
		    'title',
		    [
		        'label' => __( 'Title', 'umart-elements' ),
		        'type' => Controls_Manager::TEXTAREA,
		        'default' => __( 'Title', 'umart-elements' ),
		        'placeholder' => __( 'Title', 'umart-elements' ),
		    ]
		);
		$this->add_control(
		    'subtitle',
		    [
		        'label' => __( 'Sub Title', 'umart-elements' ),
		        'type' => Controls_Manager::TEXTAREA,
		        'default' => __( 'Sub title', 'umart-elements' ),
		        'placeholder' => __( 'Sub title', 'umart-elements' ),
		    ]
		);

 		$this->add_control(
            'content_pos',
            [
                'label' => __( 'Layout', 'umart-elements' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'left-bottom',
                'options' => [
                   'left-bottom'  => __( 'Left Bottom', 'umart-elements' ),
					'left-top'     => __( 'Left Top', 'umart-elements' ),
					'right-top'    => __( 'Right Top', 'umart-elements' ),
					'right-bottom' => __( 'Right Bottom', 'umart-elements' ),               
                ],
            ] 
        );           
		$this->add_responsive_control(
			'radius',
			[
				'label' => __( 'Border Radius', 'umart-elements' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],					
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
								
				'devices' => [ 'desktop', 'tablet', 'mobile' ],				
				'selectors' => [
					'{{WRAPPER}} .woocue-info-box' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);

       $this->end_controls_section();  


        $this->start_controls_section(
            'sec_bg',
            [
                'label' => __( 'Background', 'umart-elements' ),
            ]
        );

		$this->add_group_control(
		\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => __( 'Background', 'plugin-domain' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .woocue-info-box',
			]
		);
       $this->end_controls_section();   


        $this->start_controls_section(
            'sec_img',
            [
                'label' => __( 'Product Image', 'umart-elements' ),
            ]
        );

			$this->add_control(
			    'image',
			    [
			        'label' => __('Image','umart-elements'),
			        'type'=>Controls_Manager::MEDIA,
			        'default' => [
			            'url' => Utils::get_placeholder_image_src(),
			        ],
			        'dynamic' => [
			            'active' => true,
			        ],
			            
			    ]
			);

			$this->add_group_control(
			    Group_Control_Image_Size::get_type(),
			    [
			        'name' => 'pimage_size',
			        'default'  => 'woocommerce_thumbnail',
			        'separator' => 'none',			         
			    ]
			);

			$this->add_responsive_control(
			'image_size',
			[
				'label' => __( 'Image Size', 'umart-elements' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],					
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => '%',
						'size' => 50,
					],				
				'devices' => [ 'desktop', 'tablet', 'mobile' ],				
				'selectors' => [
					'{{WRAPPER}} .woocue-info-box .woocue-item .woocue-img img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'pos_x_type',
			[
				'label' => __( 'Horizontal Position', 'plugin-domain' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'umart-elements' ),
						'icon'  => 'eicon-h-align-left',
					],
					'right' => [
						'title' => __( 'Right', 'umart-elements' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'default' => 'right',
				'toggle' => true,
			]
		);

		$this->add_responsive_control(
			'pos_x',
			[
				'label' => __( 'Offset', 'umart-elements' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],					
					'range' => [
						'px' => [
							'min' => -500,
							'max' => 500,							
						],
						'%' => [
							'min' => -100,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 0,
					],				
				'devices' => [ 'desktop', 'tablet', 'mobile' ],				
				'selectors' => [
					'{{WRAPPER}} .woocue-info-box .woocue-item .woocue-img.woocue-pos-left'    => 'left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .woocue-info-box .woocue-item .woocue-img.woocue-pos-right' => 'right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'pos_y_type',
			[
				'label' => __( 'Vertical Position', 'plugin-domain' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'top' => [
						'title' => __( 'Top', 'metro-core' ),
						'icon'  => 'eicon-v-align-top',
					],
					'bottom' => [
						'title' => __( 'Bottom', 'metro-core' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'default' => 'bottom',
				'toggle' => true,
			]
		);


		$this->add_responsive_control(
			'pos_y',
			[
				'label' => __( 'Offset', 'umart-elements' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],					
					'range' => [
						'px' => [
							'min' => -500,
							'max' => 500,							
						],
						'%' => [
							'min' => -100,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 0,
					],				
				'devices' => [ 'desktop', 'tablet', 'mobile' ],				
				'selectors' => [
					'{{WRAPPER}} .woocue-info-box .woocue-item .woocue-img.woocue-pos-top'  => 'top: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .woocue-info-box .woocue-item .woocue-img.woocue-pos-bottom' => 'bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		
		
       $this->end_controls_section(); 

		$this->start_controls_section(
		'sec_linking',
		    [
		        'label' => __( 'Price, Link and Button', 'umart-elements' ),  
		                  
		    ]
		);    
		$this->add_control(
		    'price',
		    [
		        'label'   => __( 'Price Text', 'umart-elements' ),
		        'type'    => Controls_Manager::TEXT,
		        'default' => '$44',
		    ]
		);     



		$this->add_control(
			'price_pos_x_type',
			[
				'label' => __( 'Horizontal Position', 'plugin-domain' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'umart-elements' ),
						'icon'  => 'eicon-h-align-left',
					],
					'right' => [
						'title' => __( 'Right', 'umart-elements' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'default' => 'right',
				'toggle' => true,
			]
		);

		$this->add_responsive_control(
			'price_pos_x',
			[
				'label' => __( 'Offset', 'umart-elements' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],					
					'range' => [
						'px' => [
							'min' => -500,
							'max' => 500,							
						],
						'%' => [
							'min' => -100,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 0,
					],				
				'devices' => [ 'desktop', 'tablet', 'mobile' ],				
				'selectors' => [
					'{{WRAPPER}} .woocue-info-box .woocue-price.price-pos-left'    => 'left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .woocue-info-box .woocue-price.price-pos-right' => 'right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'price_pos_y_type',
			[
				'label' => __( 'Vertical Position', 'plugin-domain' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'top' => [
						'title' => __( 'Top', 'metro-core' ),
						'icon'  => 'eicon-v-align-top',
					],
					'bottom' => [
						'title' => __( 'Bottom', 'metro-core' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'default' => 'bottom',
				'toggle' => true,
			]
		);


		$this->add_responsive_control(
			'price_pos_y',
			[
				'label' => __( 'Offset', 'umart-elements' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],					
					'range' => [
						'px' => [
							'min' => -500,
							'max' => 500,							
						],
						'%' => [
							'min' => -100,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 0,
					],				
				'devices' => [ 'desktop', 'tablet', 'mobile' ],				
				'selectors' => [
					'{{WRAPPER}} .woocue-info-box .woocue-price.price-pos-top'  => 'top: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .woocue-info-box .woocue-price.price-pos-bottom' => 'bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

         $this->add_control(
            'pricebtnstyle',
            [
                'label' => __( 'Price Style', 'umart-elements' ),
                'type' => Controls_Manager::SELECT,                
                'options' => [
                        'price1' => __( 'Style 1', 'umart-elements' ),
                        'price2' => __( 'Style 2', 'umart-elements' ),
                        'price3' => __( 'Style 3', 'umart-elements' ),                        
                        'price4' => __( 'Style 4', 'umart-elements' ),                        
                    ],
                'default' => 'price1',
            ] 
        );
		
		$this->add_control(
		    'url',
		    [
		        'label'   => __( 'Detail URL', 'umart-elements' ),
		        'type'    => Controls_Manager::URL,
		        'placeholder' => 'https://your-link.com',		       
		    ]
		);   
		$this->end_controls_section();


        $this->start_controls_section(
            'sec_style_color',
            [
                'label' => __( 'Color', 'umart-elements' ),
                'tab' => Controls_Manager::TAB_STYLE,   
            ]
        );

		$this->add_control(
            'title_color',
            [
                'label' => __( 'Title Color', 'umart-elements' ),
                'type' => Controls_Manager::COLOR,      
				'selectors' => array( '{{WRAPPER}} .woocue-title' => 'color: {{VALUE}}' ),                                        
                
            ]
        );

		$this->add_control(
            'subtitle_color',
            [
                'label' => __( 'Subtitle Color', 'umart-elements' ),
                'type' => Controls_Manager::COLOR,   
				'selectors' => array( '{{WRAPPER}} .woocue-subtitle' => 'color: {{VALUE}}' ),                                       
             
            ]
        );		
		$this->add_control(
            'link_color',
            [
                'label' => __( 'Button/Link', 'umart-elements' ),
                'type' => Controls_Manager::COLOR,   
				'selectors' => array(
					'{{WRAPPER}} .woocue-info-box .woocue-item .woocue-btn' => 'color: {{VALUE}}',
					'{{WRAPPER}} .woocue-info-box.woocue-style-8 .woocue-item .woocue-btn::after, {{WRAPPER}} .woocue-info-box.woocue-style-9 .woocue-item .woocue-btn::after' => 'background-color: {{VALUE}}',
				                              
                ),
            ]
        );

       $this->end_controls_section();   

        $this->start_controls_section(
            'sec_typography_type',
            [
                'label' => __( 'Typography', 'umart-elements' ),
                'tab' => Controls_Manager::TAB_STYLE,   
            ]
        );


		$this->add_group_control(
		Group_Control_Typography::get_type(),
			[
			    'name' => 'title_typo',
			    'label' => __( 'Typography', 'umart-elements' ),  
			     'devices' => [ 'desktop', 'tablet', 'mobile' ],	
			   'selector' => '{{WRAPPER}} .woocue-title',
			]
		);

		$this->add_responsive_control(
			'title_typo_margin',
				[
				    'label' => __( 'Margin', 'umart-elements' ),
				    'type' => Controls_Manager::DIMENSIONS,
				    'size_units' => [ 'px', '%', 'em' ],
				    'devices' => [ 'desktop', 'tablet', 'mobile' ],					    
				    'selectors' => [
				        '{{WRAPPER}}  .woocue-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				        
				    ],
				]
			);


		$this->add_group_control(
		Group_Control_Typography::get_type(),
			[
			    'name' => 'subtitle_typo',
			    'label' => __( 'Typography', 'umart-elements' ),  
			     'devices' => [ 'desktop', 'tablet', 'mobile' ],	
			   'label'    => __( 'Subtitle', 'umart-elements' ),
				'selector' => '{{WRAPPER}} .woocue-subtitle',
			]
		);

		$this->add_responsive_control(
			'subtitle_typo_margin',
				[
				    'label' => __( 'Margin', 'umart-elements' ),
				    'type' => Controls_Manager::DIMENSIONS,
				    'size_units' => [ 'px', '%', 'em' ],
				    'devices' => [ 'desktop', 'tablet', 'mobile' ],					    
				    'selectors' => [
				        '{{WRAPPER}} .woocue-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				        
				    ],
				]
			);

		$this->add_group_control(
		Group_Control_Typography::get_type(),
			[
			    'name' => 'link_typo',
			    'label' => __( 'Typography', 'umart-elements' ),  
			     'devices' => [ 'desktop', 'tablet', 'mobile' ],	
			   'label'    => __( 'Subtitle', 'umart-elements' ),
				'selector' => '{{WRAPPER}} .woocue-info-box-1 .woocue-item .woocue-btn',
			]
		);

		$this->add_responsive_control(
			'link_typo_margin',
				[
				    'label' => __( 'Margin', 'umart-elements' ),
				    'type' => Controls_Manager::DIMENSIONS,
				    'size_units' => [ 'px', '%', 'em' ],
				    'devices' => [ 'desktop', 'tablet', 'mobile' ],					    
				    'selectors' => [
				        '{{WRAPPER}} .woocue-info-box-1 .woocue-item .woocue-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				        
				    ],
				]
			);

       $this->end_controls_section();   

    }

	protected function render() {
		$settings = $this->get_settings();
		$template = 'info-box-1';			
		return wooc_Elements_Helper::wooc_element_template( $template, $settings );
	}
}