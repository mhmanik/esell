<?php
/**
 * @author  WoocTheme
 * @since   1.0
 * @version 1.0
 */
?>

<div class="wooc-title-block-1">
	<div class="wooc-title-block">
		<?php  if($settings['sub_title']){ ?>
			<div class="woocue-sub-title"><?php echo wp_kses_post( $settings['sub_title'] );?></div>
		<?php  } ?>	
		<div class="clear"></div>
		<?php  if($settings['title']){ ?>
		<<?php echo esc_html( $settings['sec_title_tag'] );?> class="woocue-sec-title"><?php echo wp_kses_post( $settings['title'] );?></<?php echo esc_html( $settings['sec_title_tag'] );?>>	
		<?php  } ?>	
	</div>		
</div>
