<?php
/**
 * @author  WoocTheme
 * @since   1.0
 * @version 1.0
 */

namespace wooctheme\umart_elements;
use Elementor\Group_Control_Image_Size;
use Elementor\Icons_Manager;
$img =   Group_Control_Image_Size::get_attachment_image_html( $settings, 'image_size', 'image' );
?>
<div class="woocuecountdown-1 woocjs-coutdown coutdown-new-<?php echo esc_attr( $data['style'] );?>">
	<div class="woocue-left">
		
		<?php if ( $data['title'] || $data['subtitle'] ): ?>
			<div class="woocue-title-area">
				
				<?php if ( $data['style'] == "1" ){ ?>
						<?php if ( $data['title'] ): ?>
							<div class="woocue-title"><?php echo wp_kses_post( $data['title'] );?></div>
						<?php endif; ?>
					<?php }else{ ?>
						<?php if ( $data['title'] ): ?>
							<h3 class="woocue-title"><?php echo wp_kses_post( $data['title'] );?></h3>
						<?php endif; ?>
					<?php } ?>

				<?php if ( $data['style'] == "1" ){ ?>
					<?php if ( $data['subtitle'] ): ?>
						<div class="woocue-subtitle"><?php echo wp_kses_post( $data['subtitle'] );?></div>
					<?php endif; ?>
				<?php }else{ ?>
					<?php if ( $data['subtitle'] ): ?>
						<h4 class="woocue-subtitle"><?php echo wp_kses_post( $data['subtitle'] );?></h4>
					<?php endif; ?>
				<?php } ?>
			</div>
		<?php endif; ?>		

		<?php if ( $data['date'] ): ?>
			<div class="woocue-coutdown wooc-scripts-date clearfix" data-time="<?php echo esc_attr( $data['date'] ); ?>"></div>
		<?php endif; ?>

		<?php if ( $data['regular_price'] || $data['sale_price'] ): ?>
			<div class="woocue-price View-2">
				<?php if ( $data['sale_price'] ): ?>
					<span class="woocue-sale-price"><?php echo esc_html( $data['sale_price'] );?></span>
				<?php endif; ?>
				<?php if ( $data['regular_price'] ): ?>
					<span class="woocue-reg-price"><?php echo esc_html( $data['regular_price'] );?></span>
				<?php endif; ?>
				
				
			</div>
		<?php endif; ?>

	</div>
	<div class="woocue-right"><?php echo wp_kses_post( $img );?></div>
</div>