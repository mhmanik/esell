<?php
/**
 * @author  WoocTheme
 * @since   1.0
 * @version 1.0
 */
namespace wooctheme\umart_elements;

use wooctheme\Umart\Helper;

$thumb_size = 'wooctheme-size3';
$query = $data['query'];
?>
<?php if ( $query->have_posts() ) :?>
	<div class="woocuepost-2">
		<div class="woocue-sec-title-area">
			<h3 class="woocue-sec-title"><?php echo esc_html( $data['title'] );?></h3>
		</div>
		<div class="row">
			<?php while ( $query->have_posts() ) : $query->the_post();?>
				<div class="col-md-4 col-12">
					<div class="woocue-item">
						<?php if ( has_post_thumbnail() ): ?>
							<a class="woocue-thumb theme-overlay-2 theme-overlay-hover" href="<?php the_permalink(); ?>"><?php the_post_thumbnail( $thumb_size ); ?></a>
						<?php else: ?>
							<a class="woocue-thumb theme-overlay-2 theme-overlay-hover" href="<?php the_permalink(); ?>"><img src="<?php echo Helper::get_img( 'nothumb-size3.jpg' );?>"></a>
						<?php endif; ?>
						<div class="woocue-content">
							<div class="woocue-date"><?php the_time( get_option( 'date_format' ) ); ?></div>
							<h3 class="woocue-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
							<div class="woocue-author"><?php esc_html_e( "Posted by", 'umart-elements' );?> <?php the_author_posts_link(); ?></div>	
						</div>
					</div>
				</div>
			<?php endwhile;?>
		</div>
	</div>
<?php else: ?>
	<div><?php esc_html_e( 'Currently there are no posts', 'umart-elements' ); ?></div>
<?php endif;?>
<?php wp_reset_postdata();?>