<?php
/**
 * @author  WoocTheme
 * @since   1.0
 * @version 1.0
 */

namespace wooctheme\umart_elements;

$class = 'woocue-style-'.$settings['style'];

$wrapper_start = '<span class="woocue-title-inner">';
$wrapper_end   = '</span>';

if ( !empty( $settings['url']['url'] ) ) {
	$attr  = 'href="' . $settings['url']['url'] . '"';
	$attr .= !empty( $settings['url']['is_external'] ) ? ' target="_blank"' : '';
	$attr .= !empty( $settings['url']['nofollow'] ) ? ' rel="nofollow"' : '';
	$wrapper_start = '<a class="woocue-title-inner" ' . $attr . '>';
	$wrapper_end   = '</a>';
}
?>
<div class="woocueinfo-box <?php echo esc_attr( $class );?>">
	<div class="woocue-item">
		<div class="woocue-img woocue-pos-<?php echo esc_attr( $settings['pos_y_type'] );?>">
			<?php echo wp_get_attachment_image( $settings['image']['id'], 'full' );?></div>
		<h3 class="woocue-title">
			<?php echo $wrapper_start;?>
			<?php echo wp_kses_post( $settings['title'] );?>
			<?php echo $wrapper_end;?>
		</h3>
	</div>
</div>