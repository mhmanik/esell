<?php
/**
 * @author  WoocTheme
 * @since   1.0
 * @version 1.0
 */

namespace wooctheme\umart_elements;
$col_class  = "col-xl-{$settings['col_xl']} col-lg-{$settings['col_lg']} col-md-{$settings['col_md']} col-sm-{$settings['col_sm']} col-{$settings['col_mobile']} ";
$shop_permalink = get_permalink( wc_get_page_id( 'shop' ) );
if ( !empty( $settings['cat'] ) ) {
	$id = intval( $settings['cat'] );
	$shop_permalink = get_term_link( $id );
}
$block_data = array(
	'layout'         => $settings['style'],
	'cat_display'    => $settings['cat_display'] ? true : false,
	'rating_display' => $settings['rating_display'] ? true : false,
	'wishlist' 		 => $settings['wishlist'] ? true : false,
	'quickview' 	 => $settings['quickview'] ? true : false,	
	
);
$uniqueid = time().rand( 1, 99 );
$query_ids = array();
foreach ( $settings['queries'] as $key => $query ) {
	$class = $uniqueid.$key;
	foreach ( $query->posts as $post ) {
		$id = $post->ID;
		if ( array_key_exists( $id , $query_ids ) ) {
			$query_ids[$id] .= ' '. $class;
		}
		else {
			$query_ids[$id] = $class;
		}		
	}
}
global $post;
?>
<div class="woocueproduct-isotope woocueisotope-container woocue-layout-<?php echo esc_attr( $settings['layout'] );?>">
	<div class="woocue-navs-area">
		<div class="woocueisotope-tab woocue-navs">
			<?php if ( $settings['layout'] == '2' && $settings['section_title_display'] ): ?>			
				<div class="wooc-slider-title-block-1">
					<div class="wooc-title-block">
						<div class="woocue-sub-title"><?php echo wp_kses_post( $settings['sub_title'] );?></div>
						<div class="clear"></div>
						<h3 class="woocue-sec-title"><?php echo wp_kses_post( $settings['title'] );?></h3>
					</div>					
				</div>
			<?php endif; ?>
			<?php if ( $settings['section_filter_display'] ): ?>
				<div class="wooc-filter-block">
					<?php if ( $settings['filter_all_display'] ): ?>
						<a href="#" data-filter="*" class="current"><?php echo esc_html_e( 'All', 'umart-elements' );?></a>
					<?php endif; ?>
					<?php foreach ( $settings['navs'] as $key => $value ): ?>
						<a href="#" data-filter=".<?php echo esc_attr( $uniqueid.$key );?>"><?php echo esc_html( $value );?></a>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php if ( $settings['layout'] == '1' && $settings['all_link_display'] ): ?>
			<div class="woocue-viewall"><a href="<?php echo esc_url( $shop_permalink ); ?>"><?php echo esc_html( $settings['all_link_text'] );?><i class="flaticon-arow"></i></a></div>
		<?php endif; ?>
	</div>
	<div class="row woocueisotope-wrapper">
		<?php foreach ( $query_ids as $id => $class ):
			$post    = get_post( $id );
			$product = wc_get_product( $id );
			setup_postdata( $post );
			?>
			<div <?php wc_product_class( $col_class.$class, $product ); ?>>
				<?php wc_get_template( "custom/product-block/blocks.php" , compact( 'product', 'block_data' ) ); ?>
			</div>
			<?php
			wp_reset_postdata();
		endforeach; ?>
	</div>
	<?php if ( in_array( $settings['layout'], array( '1','2' ) ) && $settings['all_link_display'] ): ?>
		<div class="woocue-viewall-2 btn-style-<?php echo esc_html( $settings['btnstyle'] );?>"><a href="<?php echo esc_url( $shop_permalink ); ?>"><?php echo esc_html( $settings['all_link_text'] );?> <i class="flaticon-export"></i></a></div>
	<?php endif; ?>	
</div>