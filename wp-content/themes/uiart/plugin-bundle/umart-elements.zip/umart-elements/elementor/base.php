<?php
/**
 * @author  WoocTheme
 * @since   1.0
 * @version 1.0
 */

namespace wooctheme\umart_elements;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

    class umart_Widgets_Control{
        public function __construct(){
            $this->umart_widgets_control();                  
            
        }

    public function umart_widgets_control(){
        $sectiontitle = 'on';
        $widgets_manager = \Elementor\Plugin::instance()->widgets_manager; 

      
         $widget_files = [
            [
                'section_title' => 'on',
                'file_path' => 'elementor/widgets/title.php',
                'class' => 'Title',
            ],  
            [
                'section_title' => 'on',
                'file_path' => 'elementor/widgets/divider.php',
                'class' => 'UmartDivider',
            ],  
            [
                'section_title' => 'on',
                'file_path' => 'elementor/widgets/icon-box.php',
                'class' => 'Icon_Box',
            ], 
            [
                'section_title' => 'on',
                'file_path' => 'elementor/widgets/product-grid.php',
                'class' => 'Wooc_Product_Grid',
            ], 
            [
                'section_title' => 'on',
                'file_path' => 'elementor/widgets/product-media-grid.php',
                'class' => 'Product_Media_Grid',
            ],
            [
                'section_title' => 'on',
                'file_path' => 'elementor/widgets/product-banner-slider.php',
                'class' => 'Product_Banner_Slider',
            ],
            [
                'section_title' => 'on',
                'file_path' => 'elementor/widgets/countdown.php',
                'class' => 'Wooc_Product_Countdown',
            ], 
            [
                'section_title' => 'on',
                'file_path' => 'elementor/widgets/product-box.php',
                'class' => 'Product_Box',
            ], 
            [
                'section_title' => 'on',
                'file_path' => 'elementor/widgets/info-box.php',
                'class' => 'Info_Box',
            ], 
            [
                'section_title' => 'on',
                'file_path' => 'elementor/widgets/product-info-box.php',
                'class' => 'Product_Info_Box',
            ],   
            [
                'section_title' => 'on',
                'file_path' => 'elementor/widgets/product-isotope-filter.php',
                'class' => 'Wooc_Isotope_Filter',
            ],   
            [
                'section_title' => 'on',
                'file_path' => 'elementor/widgets/product-carousel.php',
                'class' => 'Product_Carousel',
            ],  
            [
                'section_title' => 'on',
                'file_path' => 'elementor/widgets/post-grid.php',
                'class' => 'Post_Grid',
            ],  
            [
                'section_title' => 'on',
                'file_path' => 'elementor/widgets/contact-info.php',
                'class' => 'contact_info',
            ],
            [
                'section_title' => 'on',
                'file_path' => 'elementor/widgets/faq.php',
                'class' => 'wooc_faq',
            ],
            
        ];
        foreach ($widget_files as $widget_file) {
            if ( file_exists( UMART_ELEMENTS_BASE_DIR . $widget_file['file_path'] ) && $widget_file['section_title'] == 'on' ) {                
                require_once UMART_ELEMENTS_BASE_DIR. $widget_file['file_path'];
                $class_name_with_namespace = "wooctheme\\umart_elements\\" . $widget_file['class'];
                $widgets_manager->register_widget_type( new $class_name_with_namespace() );
            }
        }


    }
}    
new umart_Widgets_Control();